package sec02.exam02;

public interface RemoteControl {
	public void turnOn();
	public void turnOff();
}
