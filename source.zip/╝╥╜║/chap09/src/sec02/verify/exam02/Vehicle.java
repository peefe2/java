package sec02.verify.exam02;

public interface Vehicle {
	public void run();
}
