package sec01.exam01;

public class Student {

}
