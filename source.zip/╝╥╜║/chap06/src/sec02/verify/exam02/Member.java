package sec02.verify.exam02;

public class Member {
	String name;
	String id;
	String password;
	int age;
}
