package sec06.exam03.package1;

public class B {
	A a;
}

