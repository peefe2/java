package sec03.verify.exam04;

public class BoardExample {
	public static void main(String[] args) {
		Board board = new Board("제목", "내용");
		//Board board = new Board("제목", "내용", "홍길동");
		//Board board = new Board("제목", "내용", "홍길동", "2025-12-31");
		//Board board = new Board("제목", "내용", "홍길동", "2025-12-31", 0);
	}
}
