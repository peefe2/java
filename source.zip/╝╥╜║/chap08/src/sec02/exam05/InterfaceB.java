package sec02.exam05;

public interface InterfaceB {
	public void methodB();
}

