package sec02.exam05;

public interface InterfaceC extends InterfaceA, InterfaceB {
	public void methodC();
}

