package sec01.verify.exam03;

public class Cat implements Soundable {
	@Override
	public String sound() {
		return "야옹";
	}
}
