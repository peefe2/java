package sec01.exam07.pack1;


public class A {
	protected String field;
	
	protected A() {
	}
	
	protected void method() {
	}
}
