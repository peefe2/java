package sec01.exam05;

//public class VeryVeryImportantPerson extends Member {
public class VeryImportantPerson {
}
