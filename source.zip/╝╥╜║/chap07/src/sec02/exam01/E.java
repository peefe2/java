package sec02.exam01;

public class E extends C {

}
